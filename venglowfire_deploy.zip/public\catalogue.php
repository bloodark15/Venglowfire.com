<?php
require_once '../config/db.php';
session_start();

// Système de recherche
$mot_cle = $_GET['q'] ?? '';
if ($mot_cle) {
    $stmt = $pdo->prepare("SELECT p.*, u.nom AS vendeur_nom FROM products p JOIN users u ON p.vendeur_id = u.id WHERE (p.titre LIKE ? OR p.description LIKE ?) AND p.stock > 0 ORDER BY p.date_publication DESC");
    $stmt->execute(['%'.$mot_cle.'%', '%'.$mot_cle.'%']);
} else {
    $stmt = $pdo->query('SELECT p.*, u.nom AS vendeur_nom FROM products p JOIN users u ON p.vendeur_id = u.id WHERE p.stock > 0 ORDER BY p.date_publication DESC');
}
$produits = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Catalogue des produits</title>
</head>
<body>
    <h2>Catalogue</h2>
    <form method="get" style="margin-bottom:10px;">
        <input type="text" name="q" value="<?= htmlspecialchars($mot_cle) ?>" placeholder="Rechercher un produit...">
        <button type="submit">Rechercher</button>
    </form>
    <table border="1">
        <tr><th>Titre</th><th>Description</th><th>Prix</th><th>Stock</th><th>Vendeur</th><th>Action</th></tr>
        <?php foreach ($produits as $p): ?>
        <tr>
            <td><?= htmlspecialchars($p['titre']) ?></td>
            <td><?= htmlspecialchars($p['description']) ?></td>
            <td><?= $p['prix'] ?> €</td>
            <td><?= $p['stock'] ?></td>
            <td><?= htmlspecialchars($p['vendeur_nom']) ?></td>
            <td>
                <form method="post" action="panier.php">
                    <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                    <input type="number" name="quantite" value="1" min="1" max="<?= $p['stock'] ?>">
                    <button type="submit" name="ajouter">Ajouter au panier</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="panier.php">Voir mon panier</a> | <a href="index.php">Accueil</a>
</body>
</html>
