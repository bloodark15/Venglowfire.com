<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'vendeur') {
    header('Location: login.php');
    exit;
}
$vendeur_id = $_SESSION['user_id'];
$message = '';

// Récupérer le produit à modifier
if (!isset($_GET['id'])) {
    header('Location: produits.php');
    exit;
}
$id = (int)$_GET['id'];
$stmt = $pdo->prepare('SELECT * FROM products WHERE id = ? AND vendeur_id = ?');
$stmt->execute([$id, $vendeur_id]);
$produit = $stmt->fetch();
if (!$produit) {
    header('Location: produits.php');
    exit;
}

// Traitement de la modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titre = $_POST['titre'] ?? '';
    $description = $_POST['description'] ?? '';
    $prix = $_POST['prix'] ?? 0;
    $stock = $_POST['stock'] ?? 1;
    $stmt = $pdo->prepare('UPDATE products SET titre = ?, description = ?, prix = ?, stock = ? WHERE id = ? AND vendeur_id = ?');
    try {
        $stmt->execute([$titre, $description, $prix, $stock, $id, $vendeur_id]);
        $message = 'Produit modifié avec succès.';
        // Rafraîchir les données
        $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ? AND vendeur_id = ?');
        $stmt->execute([$id, $vendeur_id]);
        $produit = $stmt->fetch();
    } catch (PDOException $e) {
        $message = 'Erreur : ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier produit</title>
</head>
<body>
    <h2>Modifier le produit</h2>
    <form method="post">
        <input type="text" name="titre" value="<?= htmlspecialchars($produit['titre']) ?>" required><br>
        <textarea name="description" required><?= htmlspecialchars($produit['description']) ?></textarea><br>
        <input type="number" step="0.01" name="prix" value="<?= $produit['prix'] ?>" required><br>
        <input type="number" name="stock" value="<?= $produit['stock'] ?>" required><br>
        <button type="submit">Enregistrer</button>
    </form>
    <div><?= $message ?></div>
    <a href="produits.php">Retour</a>
</body>
</html>
