<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'client') {
    header('Location: login.php');
    exit;
}
$client_id = $_SESSION['user_id'];

// Récupérer les commandes du client
$stmt = $pdo->prepare('SELECT o.*, d.adresse, d.statut AS statut_livraison, d.suivi, p.statut AS statut_paiement FROM orders o LEFT JOIN deliveries d ON o.id = d.order_id LEFT JOIN payments p ON o.id = p.order_id WHERE o.client_id = ? ORDER BY o.date_commande DESC');
$stmt->execute([$client_id]);
$commandes = $stmt->fetchAll();

// Récupérer les items pour chaque commande
$items = [];
if ($commandes) {
    $ids = array_column($commandes, 'id');
    $in  = str_repeat('?,', count($ids) - 1) . '?';
    $stmt = $pdo->prepare("SELECT oi.*, pr.titre FROM order_items oi JOIN products pr ON oi.product_id = pr.id WHERE oi.order_id IN ($in)");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $item) {
        $items[$item['order_id']][] = $item;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes commandes</title>
</head>
<body>
    <h2>Mes commandes</h2>
    <?php if (!$commandes): ?>
        <p>Aucune commande trouvée.</p>
    <?php else: ?>
        <?php foreach ($commandes as $commande): ?>
            <div style="border:1px solid #ccc; margin-bottom:20px; padding:10px;">
                <strong>Commande n°<?= $commande['id'] ?> du <?= $commande['date_commande'] ?></strong><br>
                Statut : <?= htmlspecialchars($commande['statut']) ?><br>
                Paiement : <?= htmlspecialchars($commande['statut_paiement']) ?><br>
                Livraison : <?= htmlspecialchars($commande['statut_livraison']) ?><br>
                Adresse : <?= htmlspecialchars($commande['adresse']) ?><br>
                Suivi : <?= htmlspecialchars($commande['suivi']) ?><br>
                <ul>
                <?php foreach ($items[$commande['id']] ?? [] as $item): ?>
                    <li><?= htmlspecialchars($item['titre']) ?> x <?= $item['quantite'] ?> (<?= number_format($item['prix'], 2) ?> €/u)</li>
                <?php endforeach; ?>
                </ul>
                Total : <strong><?= number_format($commande['total'], 2) ?> €</strong>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
    <a href="catalogue.php">Retour au catalogue</a> | <a href="index.php">Accueil</a>
</body>
</html>
