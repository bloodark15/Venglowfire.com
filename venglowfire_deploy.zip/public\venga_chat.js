// Bulle de chat Venga pour la page d'accueil
let chatOpen = false;
function toggleChat() {
    chatOpen = !chatOpen;
    document.getElementById('venga-chatbox').style.display = chatOpen ? 'block' : 'none';
}
document.addEventListener('DOMContentLoaded', function() {
    document.body.insertAdjacentHTML('beforeend', `
    <div id="venga-bubble" onclick="toggleChat()" style="position:fixed;bottom:30px;right:30px;width:60px;height:60px;background:#ff6600;border-radius:50%;box-shadow:0 2px 8px #888;cursor:pointer;z-index:1000;display:flex;align-items:center;justify-content:center;">
        <span style="color:#fff;font-size:32px;">💬</span>
    </div>
    <div id="venga-chatbox" style="display:none;position:fixed;bottom:100px;right:30px;width:320px;height:400px;background:#fff;border-radius:10px;box-shadow:0 2px 16px #888;z-index:1001;overflow:hidden;">
        <div style="background:#ff6600;color:#fff;padding:10px;font-weight:bold;">Venga - Support IA</div>
        <div id="venga-messages" style="height:300px;overflow-y:auto;padding:10px;font-size:14px;"></div>
        <form id="venga-form" style="display:flex;border-top:1px solid #eee;">
            <input id="venga-input" type="text" placeholder="Posez votre question..." style="flex:1;border:none;padding:10px;outline:none;">
            <button type="submit" style="background:#ff6600;color:#fff;border:none;padding:10px 16px;cursor:pointer;">Envoyer</button>
        </form>
    </div>
    `);
    document.getElementById('venga-form').onsubmit = function(e) {
        e.preventDefault();
        const input = document.getElementById('venga-input');
        const msg = input.value.trim();
        if (!msg) return;
        addMsg('Vous', msg);
        input.value = '';
        fetch('support_venga.php', {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'message='+encodeURIComponent(msg)})
            .then(r=>r.json()).then(data=>{
                addMsg('Venga', data.reponse);
            });
    };
    function addMsg(who, text) {
        const box = document.getElementById('venga-messages');
        box.innerHTML += `<div><b>${who} :</b> ${text}</div>`;
        box.scrollTop = box.scrollHeight;
    }
});
