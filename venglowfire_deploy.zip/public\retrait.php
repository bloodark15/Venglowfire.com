<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'vendeur') {
    header('Location: login.php');
    exit;
}
$vendeur_id = $_SESSION['user_id'];
// Récupérer le portefeuille
$stmt = $pdo->prepare('SELECT * FROM wallets WHERE vendeur_id = ?');
$stmt->execute([$vendeur_id]);
$wallet = $stmt->fetch();
$message = '';
require_once '../config/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!check_csrf_token($csrf_token)) {
        log_critical_error('Tentative CSRF sur retrait', 'vendeur_id='.$vendeur_id.' ip='.get_client_ip());
        send_security_alert('Alerte CSRF sur retrait', "Tentative CSRF détectée pour le vendeur $vendeur_id (IP: ".get_client_ip().").");
        $message = 'Erreur de sécurité (CSRF).';
    } else {
        $montant = floatval($_POST['montant'] ?? 0);
        $methode = $_POST['methode'] ?? '';
        $infos = $_POST['infos'] ?? '';
        if ($montant > 0 && $montant <= $wallet['solde']) {
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO withdrawals (vendeur_id, montant, methode, infos) VALUES (?, ?, ?, ?)')->execute([$vendeur_id, $montant, $methode, $infos]);
            $pdo->prepare('UPDATE wallets SET solde = solde - ? WHERE vendeur_id = ?')->execute([$montant, $vendeur_id]);
            $pdo->commit();
            $message = 'Demande de retrait enregistrée.';
        } else {
            log_critical_error('Demande de retrait avec montant invalide', 'vendeur_id='.$vendeur_id.' montant='.$montant.' ip='.get_client_ip());
            send_security_alert('Alerte retrait montant invalide', "Demande de retrait avec montant invalide pour le vendeur $vendeur_id (IP: ".get_client_ip().") : montant $montant");
            $message = 'Montant invalide.';
        }
    }
} 
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Demander un retrait</title>
</head>
<body>
    <h2>Demander un retrait</h2>
    <form method="post">
        <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
        <label>Montant (€) :</label><input type="number" name="montant" step="0.01" min="1" max="<?= $wallet['solde'] ?>" required><br>
        <label>Méthode :</label>
        <select name="methode">
            <option value="virement">Virement bancaire</option>
            <option value="paypal">PayPal</option>
        </select><br>
        <label>Informations (IBAN/PayPal email) :</label><input type="text" name="infos" required><br>
        <button type="submit">Envoyer la demande</button>
    </form>
    <div><?= $message ?></div>
    <a href="portefeuille.php">Retour au portefeuille</a>
</body>
</html>
