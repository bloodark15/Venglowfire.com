<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Gestion utilisateurs
$users = $pdo->query('SELECT id, nom, email, type, date_inscription FROM users ORDER BY date_inscription DESC')->fetchAll();
// Gestion produits
$produits = $pdo->query('SELECT p.id, p.titre, p.prix, p.stock, u.nom AS vendeur FROM products p JOIN users u ON p.vendeur_id = u.id ORDER BY p.date_publication DESC')->fetchAll();
// Gestion commandes
$commandes = $pdo->query('SELECT o.id, o.total, o.statut, o.date_commande, u.nom AS client FROM orders o JOIN users u ON o.client_id = u.id ORDER BY o.date_commande DESC')->fetchAll();
// Gestion paiements
$paiements = $pdo->query('SELECT p.id, p.order_id, p.montant, p.commission, p.statut, p.date_paiement FROM payments p ORDER BY p.date_paiement DESC')->fetchAll();

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace Admin</title>
</head>
<body>
    <h2>Espace Administrateur</h2>
    <h3>Utilisateurs</h3>
    <table border="1">
        <tr><th>ID</th><th>Nom</th><th>Email</th><th>Type</th><th>Date inscription</th></tr>
        <?php foreach ($users as $u): ?>
        <tr>
            <td><?= $u['id'] ?></td>
            <td><?= htmlspecialchars($u['nom']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><?= $u['type'] ?></td>
            <td><?= $u['date_inscription'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <h3>Produits</h3>
    <table border="1">
        <tr><th>ID</th><th>Titre</th><th>Prix</th><th>Stock</th><th>Vendeur</th></tr>
        <?php foreach ($produits as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['titre']) ?></td>
            <td><?= number_format($p['prix'], 2) ?> €</td>
            <td><?= $p['stock'] ?></td>
            <td><?= htmlspecialchars($p['vendeur']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <h3>Commandes</h3>
    <table border="1">
        <tr><th>ID</th><th>Client</th><th>Total</th><th>Statut</th><th>Date</th></tr>
        <?php foreach ($commandes as $c): ?>
        <tr>
            <td><?= $c['id'] ?></td>
            <td><?= htmlspecialchars($c['client']) ?></td>
            <td><?= number_format($c['total'], 2) ?> €</td>
            <td><?= htmlspecialchars($c['statut']) ?></td>
            <td><?= $c['date_commande'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <h3>Paiements & Commissions</h3>
    <table border="1">
        <tr><th>ID</th><th>Commande</th><th>Montant</th><th>Commission</th><th>Statut</th><th>Date</th></tr>
        <?php foreach ($paiements as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= $p['order_id'] ?></td>
            <td><?= number_format($p['montant'], 2) ?> €</td>
            <td><?= number_format($p['commission'], 2) ?> €</td>
            <td><?= htmlspecialchars($p['statut']) ?></td>
            <td><?= $p['date_paiement'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="index.php">Accueil</a>
</body>
</html>
