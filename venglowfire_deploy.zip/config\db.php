<?php
// Headers HTTP de sécurité globaux
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'");

// Configuration de la connexion à la base de données
$host = 'localhost';
$db   = 'ecommerce';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4',
];
try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
     // Log de l'erreur en production (à compléter)
     die('Erreur de connexion à la base de données.');
}

// Protection : blocage automatique des IP bannies
function get_client_ip() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    return $_SERVER['REMOTE_ADDR'] ?? '';
}
$client_ip = get_client_ip();
if (isset($pdo)) {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM banned_ips WHERE ip = ?');
    $stmt->execute([$client_ip]);
    if ($stmt->fetchColumn() > 0) {
        http_response_code(403);
        exit('Accès interdit : votre IP a été bannie pour comportement suspect.');
    }
}


// Protection basique anti-intrusion (CSRF, session, XSS, SQLi)
function secure_input($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// CSRF token functions
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function check_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Logger admin actions
function log_admin_action($admin_id, $action, $details = '') {
    $file = __DIR__ . '/../logs/admin_actions.log';
    $date = date('Y-m-d H:i:s');
    $line = "$date | admin_id:$admin_id | $action | $details\n";
    file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}

// Logger erreurs critiques pour le directeur
function log_critical_error($message, $context = '') {
    $file = __DIR__ . '/../logs/errors.log';
    $date = date('Y-m-d H:i:s');
    $line = "$date | CRITICAL | $message | $context\n";
    file_put_contents($file, $line, FILE_APPEND | LOCK_EX);
}

// Envoi d'une alerte sécurité par mail au directeur
function send_security_alert($subject, $body) {
    $to = 'bloodark.off81@gmail.com';
    $headers = "From: Venglowfire <no-reply@venglowfire.local>\r\nContent-Type: text/plain; charset=utf-8";
    @mail($to, $subject, $body, $headers);
}

