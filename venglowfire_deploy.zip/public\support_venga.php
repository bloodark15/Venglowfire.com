<?php
session_start();
header('Content-Type: application/json');

// Règles de la plateforme
$regles = "Bienvenue sur la plateforme !\nVoici les règles principales :\n- Vente de produits légaux uniquement\n- Respect des lois et conditions générales\n- Pas de contrefaçon, drogues, armes, contenus illicites\n- Respect entre utilisateurs\n- 3 avertissements = bannissement automatique\n";

$faq = [
    'bonjour' => 'Bonjour, je suis Venga, le bot support. Comment puis-je vous aider ?',
    'regle' => $regles,
    'règle' => $regles,
    'règles' => $regles,
    'règles de la plateforme' => $regles,
    'paiement' => 'Les paiements sont sécurisés via la plateforme. Une commission de 10% est prélevée sur chaque vente.',
    'livraison' => 'La livraison est gérée par chaque vendeur. Vous pouvez suivre votre commande dans votre espace client.',
    'produit interdit' => 'La vente de produits interdits entraîne un avertissement puis un bannissement.',
    'banni' => 'Après 3 avertissements pour produits interdits, le vendeur est automatiquement banni.'
];

// Traitement du message utilisateur
$question = strtolower(trim($_POST['message'] ?? ''));
$reponse = '';
foreach ($faq as $mot => $rep) {
    if (strpos($question, $mot) !== false) {
        $reponse = $rep;
        break;
    }
}
if (!$reponse) {
    $reponse = "Je suis Venga, le bot support. Je peux répondre sur les règles, paiements, livraisons, sécurité. Tapez 'règles' pour voir les règles de la plateforme.";
}
echo json_encode(['reponse' => nl2br($reponse)]);
