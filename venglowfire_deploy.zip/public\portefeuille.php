<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'vendeur') {
    header('Location: login.php');
    exit;
}
$vendeur_id = $_SESSION['user_id'];
// Initialiser le portefeuille si inexistant
$stmt = $pdo->prepare('SELECT * FROM wallets WHERE vendeur_id = ?');
$stmt->execute([$vendeur_id]);
$wallet = $stmt->fetch();
if (!$wallet) {
    $pdo->prepare('INSERT INTO wallets (vendeur_id, solde) VALUES (?, 0)')->execute([$vendeur_id]);
    $stmt->execute([$vendeur_id]);
    $wallet = $stmt->fetch();
}
// Historique des ventes créditées
$stmt = $pdo->prepare('SELECT o.id AS order_id, o.date_commande, SUM(oi.quantite*oi.prix) AS montant FROM order_items oi JOIN orders o ON oi.order_id=o.id JOIN products p ON oi.product_id=p.id WHERE p.vendeur_id=? GROUP BY o.id ORDER BY o.date_commande DESC');
$stmt->execute([$vendeur_id]);
$ventes = $stmt->fetchAll();
// Historique des retraits
$stmt = $pdo->prepare('SELECT * FROM withdrawals WHERE vendeur_id = ? ORDER BY date_demande DESC');
$stmt->execute([$vendeur_id]);
$retraits = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon portefeuille</title>
</head>
<body>
    <h2>Mon portefeuille</h2>
    <p>Solde actuel : <strong><?= number_format($wallet['solde'],2) ?> €</strong></p>
    <h3>Ventes créditées</h3>
    <table border="1">
        <tr><th>Commande</th><th>Date</th><th>Montant</th></tr>
        <?php foreach ($ventes as $v): ?>
        <tr>
            <td><?= $v['order_id'] ?></td>
            <td><?= $v['date_commande'] ?></td>
            <td><?= number_format($v['montant'],2) ?> €</td>
        </tr>
        <?php endforeach; ?>
    </table>
    <h3>Demandes de retrait</h3>
    <table border="1">
        <tr><th>Montant</th><th>Méthode</th><th>Date demande</th><th>Statut</th></tr>
        <?php foreach ($retraits as $r): ?>
        <tr>
            <td><?= number_format($r['montant'],2) ?> €</td>
            <td><?= htmlspecialchars($r['methode']) ?></td>
            <td><?= $r['date_demande'] ?></td>
            <td><?= htmlspecialchars($r['statut']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="retrait.php">Demander un retrait</a> | <a href="dashboard_vendeur.php">Tableau de bord</a> | <a href="index.php">Accueil</a>
</body>
</html>
