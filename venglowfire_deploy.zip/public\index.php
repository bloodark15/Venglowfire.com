<?php
require_once '../config/db.php';
// Page d'accueil simple
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Accueil - Venglowfire</title>
    <link rel="stylesheet" href="style.css">
    <script src="venga_chat.js"></script>
    <script>
        function toggleChat() {} // pour éviter l'erreur avant chargement du JS
    </script>
</head>
<body>
    <div id="splash-venglowfire" style="position:fixed;top:0;left:0;width:100vw;height:100vh;background:#111;z-index:9999;display:flex;align-items:center;justify-content:center;transition:opacity 1s;">
        <span style="color:#fff;font-size:3em;letter-spacing:0.15em;font-family:'Segoe UI',sans-serif;animation:glow 2s infinite alternate;">Venglowfire</span>
    </div>
    <script>
    setTimeout(function() {
        var splash = document.getElementById('splash-venglowfire');
        splash.style.opacity = 0;
        setTimeout(function(){ splash.style.display = 'none'; }, 1000);
    }, 60000);
    </script>
    <style>
    @keyframes glow {
      from { text-shadow:0 0 10px #43a047,0 0 20px #1a73e8; }
      to { text-shadow:0 0 30px #43a047,0 0 60px #1a73e8; }
    }
    </style>
    <h1>Bienvenue sur Venglowfire</h1>
    <div style="margin:30px 0;">
        <a href="login.php" style="padding:12px 32px;background:#1a73e8;color:#fff;border-radius:6px;text-decoration:none;font-size:1.2em;margin-right:20px;">Se connecter</a>
        <a href="register.php" style="padding:12px 32px;background:#43a047;color:#fff;border-radius:6px;text-decoration:none;font-size:1.2em;">S'inscrire</a>
    </div>
    <a href="register.php">Inscription</a> | <a href="login.php">Connexion</a>
    <!-- La bulle de chat Venga sera intégrée via JS -->
</body>
</html>
