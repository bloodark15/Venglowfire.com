<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$user_id = $_SESSION['user_id'];
$message = '';
// Récupérer infos utilisateur
$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom'] ?? '';
    $email = $_POST['email'] ?? '';
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';
    if ($mot_de_passe) {
        $hash = password_hash($mot_de_passe, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('UPDATE users SET nom = ?, email = ?, mot_de_passe = ? WHERE id = ?');
        $stmt->execute([$nom, $email, $hash, $user_id]);
    } else {
        $stmt = $pdo->prepare('UPDATE users SET nom = ?, email = ? WHERE id = ?');
        $stmt->execute([$nom, $email, $user_id]);
    }
    $message = 'Profil mis à jour.';
    // Refresh info
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon profil</title>
</head>
<body>
    <h2>Mon profil</h2>
    <form method="post">
        <input type="text" name="nom" value="<?= htmlspecialchars($user['nom']) ?>" required><br>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required><br>
        <input type="password" name="mot_de_passe" placeholder="Nouveau mot de passe (laisser vide pour ne pas changer)"><br>
        <button type="submit">Enregistrer</button>
    </form>
    <div><?= $message ?></div>
    <a href="index.php">Accueil</a>
</body>
</html>
