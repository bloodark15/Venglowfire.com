<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'vendeur') {
    header('Location: login.php');
    exit;
}
$vendeur_id = $_SESSION['user_id'];
$message = '';

// Liste des mots interdits
$mots_interdits = ['drogue', 'arme', 'contrefaçon', 'illicite', 'interdit', 'faux billet', 'stupéfiant', 'explosif', 'porno', 'piratage'];

// Ajout d'un produit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter'])) {
    $titre = $_POST['titre'] ?? '';
    $description = $_POST['description'] ?? '';
    $prix = $_POST['prix'] ?? 0;
    $stock = $_POST['stock'] ?? 1;
    $texte = strtolower($titre . ' ' . $description);
    $motif = '';
    foreach ($mots_interdits as $mot) {
        if (strpos($texte, $mot) !== false) {
            $motif = $mot;
            break;
        }
    }
    if ($motif) {
        // Compter les avertissements existants
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM warnings WHERE vendeur_id = ?');
        $stmt->execute([$vendeur_id]);
        $nb_avert = $stmt->fetchColumn();
        // Ajouter avertissement
        $stmt = $pdo->prepare('INSERT INTO warnings (vendeur_id, produit_id, motif) VALUES (?, NULL, ?)');
        $stmt->execute([$vendeur_id, $motif]);
        if ($nb_avert + 1 >= 3) {
            $stmt = $pdo->prepare('INSERT INTO bans (vendeur_id, motif) VALUES (?, ?)');
            $stmt->execute([$vendeur_id, '3 avertissements pour produits interdits']);
            // Bannir le vendeur
            $stmt = $pdo->prepare('UPDATE users SET type = "banni" WHERE id = ?');
            $stmt->execute([$vendeur_id]);
            $message = "Produit interdit détecté. Vous avez été banni de la plateforme.";
        } else {
            $message = "Produit interdit détecté : $motif. Avertissement $nb_avert/3.";
        }
    } else {
        $stmt = $pdo->prepare('INSERT INTO products (vendeur_id, titre, description, prix, stock) VALUES (?, ?, ?, ?, ?)');
        try {
            $stmt->execute([$vendeur_id, $titre, $description, $prix, $stock]);
            $message = 'Produit ajouté avec succès.';
        } catch (PDOException $e) {
            $message = 'Erreur : ' . $e->getMessage();
        }
    }
}

// Suppression d'un produit
if (isset($_GET['supprimer'])) {
    $id = (int)$_GET['supprimer'];
    $stmt = $pdo->prepare('DELETE FROM products WHERE id = ? AND vendeur_id = ?');
    $stmt->execute([$id, $vendeur_id]);
    $message = 'Produit supprimé.';
}

// Liste des produits du vendeur
$stmt = $pdo->prepare('SELECT * FROM products WHERE vendeur_id = ?');
$stmt->execute([$vendeur_id]);
$produits = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes produits</title>
</head>
<body>
    <h2>Gestion de mes produits</h2>
    <form method="post">
        <input type="text" name="titre" placeholder="Titre" required>
        <textarea name="description" placeholder="Description" required></textarea>
        <input type="number" step="0.01" name="prix" placeholder="Prix" required>
        <input type="number" name="stock" placeholder="Stock" required>
        <button type="submit" name="ajouter">Ajouter</button>
    </form>
    <div><?= $message ?></div>
    <h3>Mes produits</h3>
    <table border="1">
        <tr><th>ID</th><th>Titre</th><th>Prix</th><th>Stock</th><th>Actions</th></tr>
        <?php foreach ($produits as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['titre']) ?></td>
            <td><?= $p['prix'] ?></td>
            <td><?= $p['stock'] ?></td>
            <td>
                <a href="modifier_produit.php?id=<?= $p['id'] ?>">Modifier</a> |
<a href="?supprimer=<?= $p['id'] ?>" onclick="return confirm('Supprimer ce produit ?');">Supprimer</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="index.php">Retour accueil</a>
</body>
</html>
