<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'vendeur') {
    header('Location: login.php');
    exit;
}
$vendeur_id = $_SESSION['user_id'];

// Statistiques générales
$nb_produits = $pdo->query('SELECT COUNT(*) FROM products WHERE vendeur_id = ' . $vendeur_id)->fetchColumn();
$nb_ventes = $pdo->query('SELECT COUNT(DISTINCT oi.order_id) FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE p.vendeur_id = ' . $vendeur_id)->fetchColumn();
$revenu = $pdo->query('SELECT SUM(oi.prix * oi.quantite) FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE p.vendeur_id = ' . $vendeur_id)->fetchColumn();
$commission = $pdo->query('SELECT SUM(pay.commission) FROM payments pay JOIN orders o ON pay.order_id = o.id JOIN order_items oi ON oi.order_id = o.id JOIN products p ON oi.product_id = p.id WHERE p.vendeur_id = ' . $vendeur_id)->fetchColumn();

// Détail des ventes
$stmt = $pdo->prepare('SELECT o.id AS order_id, o.date_commande, u.nom AS client_nom, oi.quantite, oi.prix, d.statut AS statut_livraison FROM order_items oi JOIN orders o ON oi.order_id = o.id JOIN users u ON o.client_id = u.id JOIN products p ON oi.product_id = p.id LEFT JOIN deliveries d ON d.order_id = o.id WHERE p.vendeur_id = ? ORDER BY o.date_commande DESC');
$stmt->execute([$vendeur_id]);
$ventes = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de bord vendeur</title>
</head>
<body>
    <h2>Tableau de bord vendeur</h2>
    <h3>Statistiques</h3>
    <ul>
        <li>Nombre de produits : <?= $nb_produits ?></li>
        <li>Nombre de ventes : <?= $nb_ventes ?></li>
        <li>Revenu total : <?= number_format($revenu, 2) ?> €</li>
        <li>Commissions totales : <?= number_format($commission, 2) ?> €</li>
    </ul>
    <h3>Détail des ventes</h3>
    <table border="1">
        <tr><th>Commande</th><th>Date</th><th>Client</th><th>Quantité</th><th>Prix</th><th>Livraison</th></tr>
        <?php foreach ($ventes as $v): ?>
        <tr>
            <td><?= $v['order_id'] ?></td>
            <td><?= $v['date_commande'] ?></td>
            <td><?= htmlspecialchars($v['client_nom']) ?></td>
            <td><?= $v['quantite'] ?></td>
            <td><?= number_format($v['prix'], 2) ?> €</td>
            <td><?= htmlspecialchars($v['statut_livraison']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="produits.php">Gérer mes produits</a> | <a href="suivi_livraison.php">Suivi des livraisons</a> | <a href="messagerie.php">Messagerie</a> | <a href="index.php">Accueil</a>
</body>
</html>
