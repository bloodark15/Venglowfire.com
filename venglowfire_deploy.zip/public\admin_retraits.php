<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_type'], ['admin','directeur'])) {
    header('Location: login.php');
    exit;
}
// Traitement validation/rejet
if (isset($_GET['valider'])) {
    $id = (int)$_GET['valider'];
    $pdo->prepare('UPDATE withdrawals SET statut = "validé", date_traitement = NOW() WHERE id = ?')->execute([$id]);
}
if (isset($_GET['rejeter'])) {
    $id = (int)$_GET['rejeter'];
    $pdo->prepare('UPDATE withdrawals SET statut = "rejeté", date_traitement = NOW() WHERE id = ?')->execute([$id]);
}
// Liste des retraits
$retraits = $pdo->query('SELECT w.*, u.nom AS vendeur FROM withdrawals w JOIN users u ON w.vendeur_id = u.id ORDER BY w.date_demande DESC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des retraits</title>
</head>
<body>
    <h2>Gestion des retraits vendeurs</h2>
    <table border="1">
        <tr><th>Vendeur</th><th>Montant</th><th>Méthode</th><th>Infos</th><th>Date demande</th><th>Statut</th><th>Action</th></tr>
        <?php foreach ($retraits as $r): ?>
        <tr>
            <td><?= htmlspecialchars($r['vendeur']) ?></td>
            <td><?= number_format($r['montant'],2) ?> €</td>
            <td><?= htmlspecialchars($r['methode']) ?></td>
            <td><?= htmlspecialchars($r['infos']) ?></td>
            <td><?= $r['date_demande'] ?></td>
            <td><?= htmlspecialchars($r['statut']) ?></td>
            <td>
                <?php if ($r['statut'] === 'en attente'): ?>
                    <a href="?valider=<?= $r['id'] }">Valider</a> |
                    <a href="?rejeter=<?= $r['id'] }" onclick="return confirm('Rejeter ce retrait ?');">Rejeter</a>
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="admin.php">Retour admin</a>
</body>
</html>
