<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'directeur') {
    header('Location: login.php');
    exit;
}
// Lecture des logs admin
$log_admin = file_exists('../logs/admin_actions.log') ? file_get_contents('../logs/admin_actions.log') : 'Aucune action admin.';
// Lecture des logs d’erreurs personnalisées si besoin
$log_error = file_exists('../logs/errors.log') ? file_get_contents('../logs/errors.log') : 'Aucune erreur enregistrée.';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Logs de la plateforme</title>
    <style>pre{background:#f7f7f7;border:1px solid #ccc;padding:10px;overflow:auto;max-height:400px;}</style>
</head>
<body>
    <h2>Logs administrateur et erreurs</h2>
    <h3>Actions administrateur</h3>
    <pre><?= htmlspecialchars($log_admin) ?></pre>
    <h3>Erreurs applicatives</h3>
    <pre><?= htmlspecialchars($log_error) ?></pre>
    <a href="admin.php">Retour admin</a>
</body>
</html>
