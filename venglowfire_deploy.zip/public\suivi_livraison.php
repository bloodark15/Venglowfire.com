<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];

// Pour un client : voir ses livraisons
if ($user_type === 'client') {
    $stmt = $pdo->prepare('SELECT o.id AS order_id, d.adresse, d.statut, d.suivi, o.date_commande FROM deliveries d JOIN orders o ON d.order_id = o.id WHERE o.client_id = ? ORDER BY o.date_commande DESC');
    $stmt->execute([$user_id]);
    $livraisons = $stmt->fetchAll();
}
// Pour un vendeur : voir les livraisons de ses ventes
elseif ($user_type === 'vendeur') {
    $stmt = $pdo->prepare('SELECT o.id AS order_id, d.adresse, d.statut, d.suivi, o.date_commande, u.nom AS client_nom FROM deliveries d JOIN orders o ON d.order_id = o.id JOIN order_items oi ON oi.order_id = o.id JOIN products p ON oi.product_id = p.id JOIN users u ON o.client_id = u.id WHERE p.vendeur_id = ? GROUP BY o.id ORDER BY o.date_commande DESC');
    $stmt->execute([$user_id]);
    $livraisons = $stmt->fetchAll();
}
else {
    $livraisons = [];
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Suivi des livraisons</title>
</head>
<body>
    <h2>Suivi des livraisons</h2>
    <table border="1">
        <tr>
            <th>Commande</th>
            <th>Date</th>
            <th>Adresse</th>
            <?php if ($user_type === 'vendeur'): ?><th>Client</th><?php endif; ?>
            <th>Statut</th>
            <th>Suivi</th>
        </tr>
        <?php foreach ($livraisons as $l): ?>
        <tr>
            <td><?= $l['order_id'] ?></td>
            <td><?= $l['date_commande'] ?></td>
            <td><?= htmlspecialchars($l['adresse']) ?></td>
            <?php if ($user_type === 'vendeur'): ?><td><?= htmlspecialchars($l['client_nom']) ?></td><?php endif; ?>
            <td><?= htmlspecialchars($l['statut']) ?></td>
            <td><?= htmlspecialchars($l['suivi']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="index.php">Accueil</a>
</body>
</html>
