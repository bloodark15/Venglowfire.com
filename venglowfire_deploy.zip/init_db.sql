-- Script de création de la base de données e-commerce
CREATE DATABASE IF NOT EXISTS ecommerce CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ecommerce;

-- Table utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    nom VARCHAR(100),
    email VARCHAR(150) UNIQUE,
    mot_de_passe VARCHAR(255),
    date_naissance DATE,
    type ENUM('client', 'vendeur', 'admin', 'directeur', 'banni') DEFAULT 'client',
    date_inscription DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table portefeuilles vendeurs
CREATE TABLE IF NOT EXISTS wallets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vendeur_id INT UNIQUE,
    solde DECIMAL(12,2) DEFAULT 0,
    FOREIGN KEY (vendeur_id) REFERENCES users(id)
);

-- Table retraits (demandes de virement)
CREATE TABLE IF NOT EXISTS withdrawals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vendeur_id INT,
    montant DECIMAL(12,2),
    methode VARCHAR(50),
    statut VARCHAR(50) DEFAULT 'en attente',
    date_demande DATETIME DEFAULT CURRENT_TIMESTAMP,
    date_traitement DATETIME NULL,
    infos TEXT,
    FOREIGN KEY (vendeur_id) REFERENCES users(id)
);

-- Table infos bancaires vendeurs
CREATE TABLE IF NOT EXISTS bank_infos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vendeur_id INT,
    iban VARCHAR(34),
    titulaire VARCHAR(100),
    banque VARCHAR(100),
    swift VARCHAR(20),
    paypal_email VARCHAR(150),
    date_ajout DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendeur_id) REFERENCES users(id)
);

-- Table IP bannies
CREATE TABLE IF NOT EXISTS banned_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) UNIQUE,
    motif VARCHAR(255),
    date_ban DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table tentatives de connexion
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45),
    user VARCHAR(150),
    date_attempt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Table produits
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vendeur_id INT,
    titre VARCHAR(150),
    description TEXT,
    prix DECIMAL(10,2),
    stock INT DEFAULT 1,
    images TEXT,
    date_publication DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendeur_id) REFERENCES users(id)
);

-- Table commandes
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT,
    total DECIMAL(10,2),
    statut VARCHAR(50) DEFAULT 'en attente',
    date_commande DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES users(id)
);

-- Table items de commande
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantite INT,
    prix DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Table paiements
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    montant DECIMAL(10,2),
    commission DECIMAL(10,2),
    statut VARCHAR(50) DEFAULT 'en attente',
    date_paiement DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Table livraisons
CREATE TABLE IF NOT EXISTS deliveries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    adresse VARCHAR(255),
    statut VARCHAR(50) DEFAULT 'préparation',
    suivi VARCHAR(100),
    date_livraison DATETIME,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Table messages (messagerie client-vendeur)
CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    expediteur_id INT,
    destinataire_id INT,
    order_id INT NULL,
    contenu TEXT,
    date_envoi DATETIME DEFAULT CURRENT_TIMESTAMP,
    lu TINYINT(1) DEFAULT 0,
    FOREIGN KEY (expediteur_id) REFERENCES users(id),
    FOREIGN KEY (destinataire_id) REFERENCES users(id),
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- Table avertissements vendeurs
CREATE TABLE IF NOT EXISTS warnings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vendeur_id INT,
    produit_id INT,
    motif VARCHAR(255),
    date_warning DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendeur_id) REFERENCES users(id),
    FOREIGN KEY (produit_id) REFERENCES products(id)
);

-- Table bannissements vendeurs
CREATE TABLE IF NOT EXISTS bans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vendeur_id INT,
    motif VARCHAR(255),
    date_ban DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendeur_id) REFERENCES users(id)
);
