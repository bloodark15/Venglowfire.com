<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'vendeur') {
    header('Location: login.php');
    exit;
}
$vendeur_id = $_SESSION['user_id'];

// Liste des produits du vendeur
$stmt = $pdo->prepare('SELECT * FROM products WHERE vendeur_id = ?');
$stmt->execute([$vendeur_id]);
$produits = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes produits</title>
</head>
<body>
    <h2>Mes produits</h2>
    <table border="1">
        <tr><th>ID</th><th>Titre</th><th>Description</th><th>Prix</th><th>Stock</th></tr>
        <?php foreach ($produits as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= htmlspecialchars($p['titre']) ?></td>
            <td><?= htmlspecialchars($p['description']) ?></td>
            <td><?= $p['prix'] ?></td>
            <td><?= $p['stock'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="produits.php">Gérer mes produits</a> | <a href="index.php">Accueil</a>
</body>
</html>
