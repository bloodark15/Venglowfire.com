<?php
// AI Protection Bot - Analyse les logs d'erreur et admin pour détecter les comportements suspects
// Usage : accessible uniquement par le directeur
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'directeur') {
    header('Location: login.php');
    exit;
}

$alerts = [];
$now = time();
$window = 600; // 10 minutes
$max_critical_errors = 5;
$suspicious_users = [];
$suspicious_ips = [];

// Analyse des erreurs critiques
$error_log = file_exists('../logs/errors.log') ? file('../logs/errors.log') : [];
foreach ($error_log as $line) {
    if (preg_match('/(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) \| CRITICAL \| (.*?) \| (.*)/', $line, $matches)) {
        $date = strtotime($matches[1]);
        $msg = $matches[2];
        $ctx = $matches[3];
        if ($now - $date < $window) {
            if (preg_match('/vendeur_id=(\d+)/', $ctx, $m)) {
                $uid = $m[1];
                if (!isset($suspicious_users[$uid])) $suspicious_users[$uid] = 0;
                $suspicious_users[$uid]++;
            }
            if (preg_match('/ip=([0-9a-fA-F:\.]+)/', $ctx, $mip)) {
                $ip = $mip[1];
                if (!isset($suspicious_ips[$ip])) $suspicious_ips[$ip] = 0;
                $suspicious_ips[$ip]++;
            }
        }
    }
}
foreach ($suspicious_users as $uid => $count) {
    if ($count >= $max_critical_errors) {
        // Ajouter à la table bans si non déjà présent
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM bans WHERE user_id = ?');
        $stmt->execute([$uid]);
        if ($stmt->fetchColumn() == 0) {
            $pdo->prepare('INSERT INTO bans (user_id, motif, date_ban) VALUES (?, ?, NOW())')->execute([$uid, 'Trop d\'erreurs critiques détectées par l\'AI Protection Bot']);
            $alerts[] = "Utilisateur ID $uid banni automatiquement pour activité suspecte.";
        }
    }
}
foreach ($suspicious_ips as $ip => $count) {
    if ($count >= $max_critical_errors) {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM banned_ips WHERE ip = ?');
        $stmt->execute([$ip]);
        if ($stmt->fetchColumn() == 0) {
            $pdo->prepare('INSERT INTO banned_ips (ip, motif) VALUES (?, ?)')->execute([$ip, "Trop d'erreurs critiques détectées par l'AI Protection Bot"]);
            $alerts[] = "IP $ip bannie automatiquement pour activité suspecte.";
        }
    }
}

// Rapport
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>AI Protection Bot - Rapport</title>
    <style>body{font-family:sans-serif;} .alert{color:red;}</style>
</head>
<body>
    <h2>AI Protection Bot - Surveillance</h2>
    <?php if ($alerts): ?>
        <div class="alert">
            <h3>Alertes :</h3>
            <ul>
                <?php foreach ($alerts as $a): ?><li><?= htmlspecialchars($a) ?></li><?php endforeach; ?>
            </ul>
        </div>
    <?php else: ?>
        <p>Aucune activité suspecte détectée dans les 10 dernières minutes.</p>
    <?php endif; ?>
    <a href="logs_directeur.php">Retour logs</a>
</body>
</html>
