<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'client') {
    header('Location: login.php');
    exit;
}
if (empty($_SESSION['panier'])) {
    header('Location: panier.php');
    exit;
}
$client_id = $_SESSION['user_id'];
$message = '';

// Traitement de la commande
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $adresse = $_POST['adresse'] ?? '';
    if ($adresse) {
        $pdo->beginTransaction();
        try {
            // Calcul du total
            $ids = array_keys($_SESSION['panier']);
            $in  = str_repeat('?,', count($ids) - 1) . '?';
            $stmt = $pdo->prepare("SELECT id, prix, stock FROM products WHERE id IN ($in) FOR UPDATE");
            $stmt->execute($ids);
            $produits = $stmt->fetchAll();
            $total = 0;
            foreach ($produits as $p) {
                $qte = $_SESSION['panier'][$p['id']];
                if ($qte > $p['stock']) throw new Exception('Stock insuffisant');
                $total += $p['prix'] * $qte;
            }
            // Créer la commande
            $stmt = $pdo->prepare('INSERT INTO orders (client_id, total, statut) VALUES (?, ?, ?)');
            $stmt->execute([$client_id, $total, 'en attente']);
            $order_id = $pdo->lastInsertId();
            // Ajouter les items et mettre à jour le stock
            foreach ($produits as $p) {
                $qte = $_SESSION['panier'][$p['id']];
                $stmt = $pdo->prepare('INSERT INTO order_items (order_id, product_id, quantite, prix) VALUES (?, ?, ?, ?)');
                $stmt->execute([$order_id, $p['id'], $qte, $p['prix']]);
                $stmt = $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ?');
                $stmt->execute([$qte, $p['id']]);
            }
            // Paiement (simulation)
            $commission = $total * 0.10; // 10% de commission vendeur
            $stmt = $pdo->prepare('INSERT INTO payments (order_id, montant, commission, statut) VALUES (?, ?, ?, ?)');
            $stmt->execute([$order_id, $total, $commission, 'payé']);
            // Livraison
            $stmt = $pdo->prepare('INSERT INTO deliveries (order_id, adresse, statut) VALUES (?, ?, ?)');
            $stmt->execute([$order_id, $adresse, 'préparation']);
            $pdo->commit();
            $_SESSION['panier'] = [];
            $message = 'Commande validée avec succès !';
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = 'Erreur : ' . $e->getMessage();
        }
    } else {
        $message = 'Adresse requise.';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Valider ma commande</title>
</head>
<body>
    <h2>Validation de la commande</h2>
    <?php if ($message) echo '<div>' . $message . '</div>'; ?>
    <?php if (!$message): ?>
    <form method="post">
        <label>Adresse de livraison :</label><br>
        <textarea name="adresse" required></textarea><br>
        <button type="submit">Valider la commande</button>
    </form>
    <?php endif; ?>
    <a href="panier.php">Retour au panier</a> | <a href="index.php">Accueil</a>
</body>
</html>
