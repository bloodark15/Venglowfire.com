<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}
$message = '';
// Ajouter un produit au panier
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter'])) {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $quantite = max(1, (int)($_POST['quantite'] ?? 1));
    if (!isset($_SESSION['panier'][$product_id])) {
        $_SESSION['panier'][$product_id] = $quantite;
    } else {
        $_SESSION['panier'][$product_id] += $quantite;
    }
    $message = 'Produit ajouté au panier.';
}
// Supprimer un produit du panier
if (isset($_GET['supprimer'])) {
    $id = (int)$_GET['supprimer'];
    unset($_SESSION['panier'][$id]);
}
// Récupérer les infos des produits du panier
$ids = array_keys($_SESSION['panier']);
$produits = [];
$total = 0;
if ($ids) {
    $in  = str_repeat('?,', count($ids) - 1) . '?';
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($in)");
    $stmt->execute($ids);
    $produits = $stmt->fetchAll();
    foreach ($produits as &$p) {
        $p['quantite'] = $_SESSION['panier'][$p['id']];
        $p['sous_total'] = $p['prix'] * $p['quantite'];
        $total += $p['sous_total'];
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mon panier</title>
</head>
<body>
    <h2>Mon panier</h2>
    <?php if ($message) echo '<div>' . $message . '</div>'; ?>
    <table border="1">
        <tr><th>Titre</th><th>Prix</th><th>Quantité</th><th>Sous-total</th><th>Action</th></tr>
        <?php foreach ($produits as $p): ?>
        <tr>
            <td><?= htmlspecialchars($p['titre']) ?></td>
            <td><?= $p['prix'] ?> €</td>
            <td><?= $p['quantite'] ?></td>
            <td><?= number_format($p['sous_total'], 2) ?> €</td>
            <td><a href="?supprimer=<?= $p['id'] ?>">Supprimer</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <p><strong>Total : <?= number_format($total, 2) ?> €</strong></p>
    <a href="catalogue.php">Continuer mes achats</a> |
    <a href="commande.php">Valider la commande</a> |
    <a href="index.php">Accueil</a>
</body>
</html>
