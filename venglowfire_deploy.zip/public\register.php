<?php
require_once '../config/db.php';
session_start();
$message = '';
function secure_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = secure_input($_POST['username'] ?? '');
    $nom = secure_input($_POST['nom'] ?? '');
    $email = secure_input($_POST['email'] ?? '');
    $date_naissance = $_POST['date_naissance'] ?? '';
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';
    $type = $_POST['type'] ?? 'client';
    $captcha = intval($_POST['captcha'] ?? 0);
    $erreurs = [];
    // Vérif unicité username/email
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = ?');
    $stmt->execute([$username]);
    if ($stmt->fetchColumn() > 0) $erreurs[] = "Nom d'utilisateur déjà pris.";
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE email = ?');
    $stmt->execute([$email]);
    if ($stmt->fetchColumn() > 0) $erreurs[] = "Email déjà utilisé.";
    // Vérif majorité
    if (strtotime($date_naissance) > strtotime('-18 years')) $erreurs[] = "Vous devez avoir au moins 18 ans.";
    // Vérif force mot de passe
    if (strlen($mot_de_passe) < 8 || !preg_match('/[0-9]/',$mot_de_passe) || !preg_match('/[A-Za-z]/',$mot_de_passe)) $erreurs[] = "Mot de passe trop faible (8 caractères, lettres et chiffres).";
    // Vérif captcha
    if ($captcha !== ($_SESSION['captcha'] ?? -1)) $erreurs[] = "Captcha incorrect.";
    if (!$erreurs) {
        $hash = password_hash($mot_de_passe, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (username, nom, email, mot_de_passe, date_naissance, type) VALUES (?, ?, ?, ?, ?, ?)');
        $stmt->execute([$username, $nom, $email, $hash, $date_naissance, $type]);
        header('Location: login.php?register=1'); exit;
    } else {
        $message = implode('<br>', $erreurs);
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Inscription</title>
</head>
<body>
    <h2>Inscription</h2>
    <form method="post">
        <label>Nom d'utilisateur :</label><input type="text" name="username" required><br>
        <label>Nom :</label><input type="text" name="nom" required><br>
        <label>Email :</label><input type="email" name="email" required><br>
        <label>Date de naissance :</label><input type="date" name="date_naissance" required><br>
        <label>Mot de passe :</label><input type="password" name="mot_de_passe" required><br>
        <label>Type de compte :</label>
        <select name="type">
            <option value="client">Client</option>
            <option value="vendeur">Vendeur</option>
        </select><br>
        <?php
        // Captcha mathématique simple
        $a = rand(1,9); $b = rand(1,9); $_SESSION['captcha'] = $a+$b;
        ?>
        <label>Captcha : Combien font <?= $a ?> + <?= $b ?> ?</label>
        <input type="number" name="captcha" required><br>
        <button type="submit">S'inscrire</button>
    </form>
    <div><?= $message ?></div>
    <a href="index.php">Retour</a>
</body>
</html>
