<?php
require_once '../config/db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];
$message = '';

// Récupérer la liste des interlocuteurs (clients pour vendeurs, vendeurs pour clients)
if ($user_type === 'client') {
    $stmt = $pdo->prepare('SELECT DISTINCT u.id, u.nom FROM messages m JOIN users u ON m.expediteur_id = u.id OR m.destinataire_id = u.id WHERE (m.expediteur_id = ? OR m.destinataire_id = ?) AND u.id != ?');
    $stmt->execute([$user_id, $user_id, $user_id]);
    $interlocuteurs = $stmt->fetchAll();
} elseif ($user_type === 'vendeur') {
    $stmt = $pdo->prepare('SELECT DISTINCT u.id, u.nom FROM messages m JOIN users u ON m.expediteur_id = u.id OR m.destinataire_id = u.id WHERE (m.expediteur_id = ? OR m.destinataire_id = ?) AND u.id != ?');
    $stmt->execute([$user_id, $user_id, $user_id]);
    $interlocuteurs = $stmt->fetchAll();
} else {
    $interlocuteurs = [];
}

// Sélectionner un interlocuteur
$destinataire_id = isset($_GET['user']) ? (int)$_GET['user'] : 0;

// Envoyer un message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $destinataire_id && isset($_POST['contenu'])) {
    $contenu = trim($_POST['contenu']);
    if ($contenu) {
        $stmt = $pdo->prepare('INSERT INTO messages (expediteur_id, destinataire_id, contenu) VALUES (?, ?, ?)');
        $stmt->execute([$user_id, $destinataire_id, $contenu]);
        $message = 'Message envoyé.';
    }
}

// Afficher la conversation
$conversations = [];
if ($destinataire_id) {
    $stmt = $pdo->prepare('SELECT m.*, u.nom AS expediteur_nom FROM messages m JOIN users u ON m.expediteur_id = u.id WHERE (m.expediteur_id = ? AND m.destinataire_id = ?) OR (m.expediteur_id = ? AND m.destinataire_id = ?) ORDER BY m.date_envoi ASC');
    $stmt->execute([$user_id, $destinataire_id, $destinataire_id, $user_id]);
    $conversations = $stmt->fetchAll();
    // Marquer comme lus les messages reçus non lus
    $pdo->prepare('UPDATE messages SET lu = 1 WHERE destinataire_id = ? AND expediteur_id = ? AND lu = 0')->execute([$user_id, $destinataire_id]);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Messagerie</title>
</head>
<body>
    <h2>Messagerie</h2>
    <div style="float:left; width:200px;">
        <h4>Interlocuteurs</h4>
        <ul>
            <?php foreach ($interlocuteurs as $i): ?>
                <li><a href="?user=<?= $i['id'] ?>"<?= $destinataire_id == $i['id'] ? ' style="font-weight:bold;"' : '' ?>><?= htmlspecialchars($i['nom']) ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div style="margin-left:220px;">
        <?php if ($destinataire_id): ?>
            <div style="border:1px solid #ccc; padding:10px; height:300px; overflow-y:scroll; background:#fafafa;">
                <?php foreach ($conversations as $msg): ?>
                    <div><strong><?= htmlspecialchars($msg['expediteur_nom']) ?>:</strong> <?= htmlspecialchars($msg['contenu']) ?> <span style="font-size:10px; color:#888;">[<?= $msg['date_envoi'] ?>]</span></div>
                <?php endforeach; ?>
            </div>
            <form method="post" style="margin-top:10px;">
                <textarea name="contenu" required style="width:100%;height:50px;"></textarea><br>
                <button type="submit">Envoyer</button>
            </form>
            <div><?= $message ?></div>
        <?php else: ?>
            <p>Sélectionnez un interlocuteur pour commencer une conversation.</p>
        <?php endif; ?>
    </div>
    <div style="clear:both;"></div>
    <a href="index.php">Accueil</a>
</body>
</html>
